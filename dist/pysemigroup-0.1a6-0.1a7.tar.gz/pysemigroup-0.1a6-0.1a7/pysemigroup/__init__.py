from automata import Automaton
from transition_semigroup import TransitionSemiGroup
from regular_language import RegularLanguage
from automata import _star
