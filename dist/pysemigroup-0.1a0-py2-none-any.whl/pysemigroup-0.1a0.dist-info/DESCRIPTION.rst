# pysemigroup
A python implementation of semigroup algorithms. 


